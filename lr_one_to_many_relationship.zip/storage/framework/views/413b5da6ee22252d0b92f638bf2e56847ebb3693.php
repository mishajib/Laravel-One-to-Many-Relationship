<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-footer" style="position: fixed;bottom: 0;">
                    &copy; <?php echo e(now()->year); ?> MI SHAJIB. ALL RIGHTS RESERVED.
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<!-- Sweet Alert 2 -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@8.3.0/dist/sweetalert2.all.min.js"></script>
<!-- Sweet Alert 2 End -->
<!-- Toastr Js -->
<script src="http://cdn.bootcss.com/jquery/2.2.4/jquery.min.js"></script>
<script src="https://cdn.bootcss.com/toastr.js/latest/js/toastr.min.js"></script>
<?php echo Toastr::message(); ?>

<!-- Toastr Js End -->
<script>
    <?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    toastr.error('<?php echo e($error); ?>', 'Error', {
        closeButton: true,
        progressBar: true,
    });
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</script>
<?php echo $__env->yieldPushContent('js'); ?>

</body>
</html>
<?php /**PATH D:\Web Development\laravel\laravel relationships\lr_one_to_many_relationship\resources\views/layouts/partials/footer.blade.php ENDPATH**/ ?>