<?php echo $__env->make('layouts.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container mt-5">
    <div class="row">
        <div class="col-md-12">
            <?php echo $__env->yieldContent('main-content'); ?>
        </div>
    </div>
</div>


<?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\Web Development\laravel\laravel relationships\lr_one_to_one_relationship\resources\views/layouts/app.blade.php ENDPATH**/ ?>