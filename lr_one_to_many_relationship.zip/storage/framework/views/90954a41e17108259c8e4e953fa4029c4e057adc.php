<?php $__env->startSection('site-title', 'One to One RelationShip'); ?>


<?php $__env->startSection('header-title', 'ONE TO ONE RELATIONSHIP'); ?>


<?php $__env->startSection('main-content'); ?>
    <div class="card">
        <div class="card-header bg-secondary">
            <h3 class="card-title">Show Data</h3>
            <a href="<?php echo e(route('index')); ?>" class="btn btn-primary float-right" style="margin-top: -40px;">Back</a>
        </div>
        <div class="card-body">
            <?php if(!empty($person)): ?>
                <h1>Name: <?php echo e($person->name); ?></h1>
            <?php else: ?>
                <h1>Name: No data found!</h1>
            <?php endif; ?>

            <?php if(!empty($person->ticket)): ?>
               <h3>Ticket ID: <?php echo e($person->ticket->movie_ticket_id); ?></h3>
            <?php else: ?>
                <h3>Ticket ID: No data found!</h3>
            <?php endif; ?>

            <a href="<?php echo e(route('edit', $person->id)); ?>" class="btn btn-primary">Edit</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web Development\laravel\laravel relationships\lr_one_to_one_relationship\resources\views/show.blade.php ENDPATH**/ ?>