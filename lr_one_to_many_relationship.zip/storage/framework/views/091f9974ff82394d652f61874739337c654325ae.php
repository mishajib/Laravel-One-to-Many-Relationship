<?php $__env->startSection('site-title', 'One to One RelationShip'); ?>


<?php $__env->startSection('header-title', 'ONE TO ONE RELATIONSHIP'); ?>


<?php $__env->startSection('main-content'); ?>
    <div class="card">
        <div class="card-header bg-secondary">
            <h3 class="card-title">Show Data</h3>
            <a href="<?php echo e(route('ticket.index')); ?>" class="btn btn-primary float-right" style="margin-top: -40px;">Back</a>
        </div>
        <div class="card-body">
            <h1>Ticket: <?php echo e($ticket->movie_ticket_id); ?></h1>
            <h3>Person Name: <?php echo e($ticket->person->name); ?></h3>
            <a href="<?php echo e(route('ticket.edit', $ticket->id)); ?>" class="btn btn-primary">Edit</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web Development\laravel\laravel relationships\lr_one_to_one_relationship\resources\views/ticket/show.blade.php ENDPATH**/ ?>