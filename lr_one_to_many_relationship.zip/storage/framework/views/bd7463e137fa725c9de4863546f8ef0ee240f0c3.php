<?php $__env->startSection('site-title', 'One to One RelationShip'); ?>


<?php $__env->startSection('header-title', 'ONE TO ONE RELATIONSHIP'); ?>


<?php $__env->startSection('main-content'); ?>
    <div class="card">
        <div class="card-header bg-secondary">
            <h3 class="card-title">View All Data</h3>
            <a href="<?php echo e(route('create')); ?>" class="btn btn-primary float-right" style="margin-top: -40px;">Add New</a>
            <a href="<?php echo e(route('ticket.index')); ?>" class="btn btn-primary float-right" style="margin-top: -40px; margin-right: 100px;">Ticket</a>
        </div>
        <div class="card-body">
            <table class="table table-bordered table-dark text-center">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Name</th>
                    <th scope="col">Action</th>
                </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $persons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$key); ?></td>
                            <td><?php echo e($person->name); ?></td>
                            <td>
                                <a href="<?php echo e(route('edit', $person->id)); ?>" class="btn btn-info btn-sm">
                                    <i class="fa fa-edit"></i>
                                </a>

                                <button onclick="deletePerson(<?php echo e($person->id); ?>)" class="btn btn-danger" type="button">
                                    <i class="fa fa-trash"></i>
                                </button>
                                <form id="delete-form-<?php echo e($person->id); ?>" action="<?php echo e(route('destroy', $person->id)); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                </form>

                                <a href="<?php echo e(route('show', $person->id)); ?>" class="btn btn-primary btn-sm">
                                    <i class="fa fa-eye"></i>
                                </a>
                            </td>
                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        function deletePerson(id) {
            const swalWithBootstrapButtons = Swal.mixin({
                customClass: {
                    confirmButton: 'btn btn-success',
                    cancelButton: 'btn btn-danger'
                },
                buttonsStyling: false,
            })

            swalWithBootstrapButtons.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                type: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'No, cancel!',
                reverseButtons: true
            }).then((result) => {
                if (result.value) {
                    event.preventDefault();
                    document.getElementById('delete-form-'+id).submit();
                } else if (
                    // Read more about handling dismissals
                    result.dismiss === Swal.DismissReason.cancel
                ) {
                    swalWithBootstrapButtons.fire(
                        'Cancelled',
                        'Your data is safe :)',
                        'error'
                    )
                }
            })
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web Development\laravel\laravel relationships\lr_one_to_one_relationship\resources\views/welcome.blade.php ENDPATH**/ ?>