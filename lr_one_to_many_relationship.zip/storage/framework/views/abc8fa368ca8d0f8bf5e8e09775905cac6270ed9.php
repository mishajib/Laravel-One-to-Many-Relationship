<?php $__env->startSection('site-title', 'One to Many RelationShip'); ?>


<?php $__env->startSection('header-title', 'ONE TO MANY RELATIONSHIP'); ?>


<?php $__env->startSection('main-content'); ?>
    <div class="card">
        <div class="card-header bg-secondary">
            <h3 class="card-title">View All Numbers</h3>
            <a href="<?php echo e(route('mobile.create')); ?>" class="btn btn-primary float-right" style="margin-top: -40px;">Add New</a>
            <a href="<?php echo e(route('index')); ?>" class="btn btn-primary float-right" style="margin-top: -40px; margin-right: 100px;">Back</a>
        </div>
        <div class="card-body">
            <table class="table table-bordered table-dark text-center">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Numbers</th>
                    <th scope="col">User</th>
                    <th scope="col">Action</th>
                </tr>
                </thead>
                <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $mobiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$mobile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e(++$key); ?></td>
                                <td><?php echo e($mobile->number); ?></td>
                                <td><?php echo e($mobile->user->name); ?></td>
                                <td>
                                    <a href="<?php echo e(route('mobile.edit', $mobile->id)); ?>" class="btn btn-info btn-sm">
                                        <i class="fa fa-edit"></i>
                                    </a>

                                    <button onclick="deleteMobile(<?php echo e($mobile->id); ?>)" class="btn btn-danger" type="button">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                    <form id="delete-form-<?php echo e($mobile->id); ?>" action="<?php echo e(route('mobile.destroy', $mobile->id)); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                    </form>

                                    <a href="<?php echo e(route('mobile.show', $mobile->id)); ?>" class="btn btn-primary btn-sm">
                                        <i class="fa fa-eye"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="3">No data found!</td>
                            </tr>
                        <?php endif; ?>

                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>
        function deleteMobile(id) {
            const swalWithBootstrapButtons = Swal.mixin({
                customClass: {
                    confirmButton: 'btn btn-success',
                    cancelButton: 'btn btn-danger'
                },
                buttonsStyling: false,
            })

            swalWithBootstrapButtons.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                type: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'No, cancel!',
                reverseButtons: true
            }).then((result) => {
                if (result.value) {
                    event.preventDefault();
                    document.getElementById('delete-form-'+id).submit();
                } else if (
                    // Read more about handling dismissals
                    result.dismiss === Swal.DismissReason.cancel
                ) {
                    swalWithBootstrapButtons.fire(
                        'Cancelled',
                        'Your data is safe :)',
                        'error'
                    )
                }
            })
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Web Development\laravel\laravel relationships\lr_one_to_many_relationship\resources\views/mobile/index.blade.php ENDPATH**/ ?>